<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>

.dropdown-menu {
    padding: .7rem 0rem;
    font-size: .875rem;
    line-height: 22px;
    color: #5c5776;    
    border: none;
    box-shadow: 0 10px 30px 0 rgba(31, 45, 61, 0.1);
    border-radius: .5rem;
      
}
.dropdown-menu{
 display: block;
            visibility: hidden;
            opacity: 0;
            -webkit-transform: translateY(20px);
            -ms-transform: translateY(20px);
            transform: translateY(20px);
            -webkit-transition: all 0.3s ease-in;
            -o-transition: all 0.3s ease-in;
            transition: all 0.3s ease-in;
        }
        .dropdown {
            &:hover {
                >.dropdown-menu {
                    -webkit-transform: scaleY(1);
                    -ms-transform: scaleY(1);
                    transform: scaleY(1);
                    opacity: 1;
                    visibility: visible;
                }
            }
        }
        .dropdown-submenu {
            &:hover {
                >.dropdown-menu {
                    -webkit-transform: scaleY(1);
                    -ms-transform: scaleY(1);
                    transform: scaleY(1);
                    opacity: 1;
                    visibility: visible;
                }
            }
}
@media (min-width: 990px){
  
    .dropright-lg {
        position: relative;
   .dropdown-menu{
        top: 0;
    right: auto;
    left: 100%;
    margin-top: 0;
    margin-right: 0.125rem;
    }
}
}
.dropdown-toggle::after {
    display: inline-block;
    margin-left: .255em;
    vertical-align: .255em;    
    content: ">";
    border-top: 0rem;
    border-right: 0rem;
    border-bottom: 0;
    border-left: 0rem;
    float: right;
   
}

.avatar-md {
  width: 56px;
  height: 56px;
  
}
.avatar img {
  width: 100%;
  height: 100%;
  -o-object-fit: cover;
  object-fit: cover;
}


.avatar {
  position: relative;
  display: inline-block;
  width: 3rem;
  height: 3rem;
  font-size: 1rem;
}


.avatar-online:before {
  background-color: green;
}


.avatar-indicators:before {
  content: "";
  position: absolute;
  bottom: 0px;
  right: 5%;
  width: 30%;
  height: 30%;
  border-radius: 50%;
  border: 2px solid #fff;
  display: table;

 }

  </style>
</head>
<body>
  <div class="container py-5 " style="  margin-left: 0px;">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-12">
<ul class="list-unstyled">
<li class="dropdown ml-2">
      
          <a class="rounded-circle " href="#" role="button" id="dropdownUser"
            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <div class="avatar avatar-md avatar-indicators avatar-online">
              <img alt="avatar" src="<?php echo base_url('images/sh.jpg'); ?>

" class="rounded-circle">
            </div>
          </a> 
  
          <div class="dropdown-menu pb-2" aria-labelledby="dropdownUser">
            <div class="dropdown-item">
              <div class="d-flex py-2">
                <div class="avatar avatar-md avatar-indicators avatar-online">
                  <img alt="avatar" src="<?php echo base_url('images/sh.jpg'); ?>" class="rounded-circle">
                </div>
                <div class="ml-3 lh-1">
                  <h5 class="mb-0" style="color: black;"><i class="fa fa-user" style="font-size:20px"></i>
                     <?php echo $row->name;?></h5>
                  <p class="mb-0"><i class="fa fa-phone" style="font-size:20px" ></i> <?php echo $row->phnumber;?></p>
                  <p class="mb-0"><i class="fa fa-envelope" style="font-size:20px"></i> <?php echo $row->email;?></p>
                  <p class="mb-0"><i class="fa fa-map-marker" style="font-size:20px"></i> <?php echo $row->Address;?></p>
                </div>
  
              </div>
              
            </div>
            <div class="dropdown-divider"></div>
            <div class="">
              <ul class="list-unstyled">
                <li class="dropdown-submenu dropright-lg">
                  <a class="dropdown-item dropdown-list-group-item dropdown-toggle" href="#">
                    <span class="mr-1">
<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    </span>Profile
                  </a>
                  <ul class="dropdown-menu">
                    <li>
                      <a class="dropdown-item text-danger" href="<?php echo site_url('welcome/updateuserprofileview') ?>">
                        Update Profile
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item text-info" href="<?php echo base_url().'index.php/welcome/userresetpassview' ?>">
                        Reset Password
                      </a>
                    </li>
                    
                  </ul>
                </li>
                
              
      
                <li>
                  <a class="dropdown-item" href="@@webRoot/pages/profile-edit.html">
                    <span class="mr-1">
                      
<svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                    </span>View Profile
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" href="@@webRoot/pages/student-subscriptions.html"><span class="mr-2">
<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-star"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg></span>Subscription
                  </a>
                </li>
                <li>
                  <a class="dropdown-item" href="#!">
                    <span class="mr-2">
<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-settings"><circle cx="12" cy="12" r="3"></circle><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path></svg></span>Settings
                  </a>
                </li>
                
              
              </ul>
            </div>
            <div class="dropdown-divider"></div>
            <ul class="list-unstyled">
            <li>
              <a class="dropdown-item" href="<?php echo base_url().'index.php/welcome/userlogout' ?>">
                <span class="mr-2">
<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-power"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path><line x1="12" y1="2" x2="12" y2="12"></line></svg></span>Sign Out
              </a>
            </li>
          
          </ul>
            
          </div>
      </li>
</ul>

</div>
      
</div>
</div> </div>
</body>
</html>
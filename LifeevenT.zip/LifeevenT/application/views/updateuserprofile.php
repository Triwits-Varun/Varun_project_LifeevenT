<!-- <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Style inputs */
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=tel], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=password], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

/* Style the container/contact section */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 10px;
}

/* Create two columns that float next to eachother */
.column {
  float: left;
  width: 50%;
  margin-top: 6px;
  padding: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}



/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
</head>
<body>
<div class="container">
  <div style="text-align:center">
   
    <h2>Update User Profile</h1>
    <p>We respect your effort to Registering with us thank you!!!!</p>
    <p>Let's make the event Memorable</p>
  </div>
  <div class="row">
    <div class="column">
      <img src="<?php echo base_url('images/joinus.jpg'); ?>" height="80%" width="80%">


    </div>
    <div class="column">
      <form action="<?php echo base_url().'index.php/welcome/registeruser' ?>" method="post">
        <label >Name</label>
        <input type="text" id="name" name="name" placeholder="Your name.." onkeypress="return allowOnlyLetters(event,this);" value="<?php echo $row->name?>" required>
        <label >Email ID</label>
        <input type="email" id="email" name="email" placeholder="Your email.." value="<?php echo $row->email?>" required>
        <label >Phone Number</label>
        <input type="tel" id="phnumber" name="phnumber" onkeypress="return onlyNumberKey(event)" maxlength="10" placeholder="Your Phone Number .." value="<?php echo $row->phnumber?>" required>
         <label >Address</label>
        <input type="tel" id="Address" name="Address" placeholder="Your Address .." value="<?php echo $row->Address?>" required>
        

        <input type="submit">
        <p>Don't Update <a href="<?php echo base_url().'index.php/welcome/userwelcome' ?>" style="color:red; font-size: 20px;">back ??</a> </p> 
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
      // this function will allow onlu characters in the input field
      function allowOnlyLetters(e, t)  {    
        if (window.event){    
          var charCode = window.event.keyCode;    
        } else if (e){    
          var charCode = e.which;    
        }else { return true; }  
        // Only ASCII character in that range allowed  
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))    
          return true;    
        else{    
          return false;
        }
      } 
      function onlyNumberKey(evt) {
              
              // Only ASCII character in that range allowed
              var ASCIICode = (evt.which) ? evt.which : evt.keyCode
              if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                  return false;
              return true;
          } 
          function Validate( ) {
        var password = document.getElementById("password").value;
        var confirm_password = document.getElementById("confirm_password").value;
        if (password != confirm_password) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
      }   
</script>
</body>
</html>
 -->
 <!-- <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    /* Import Font Dancing Script */
@import url(https://fonts.googleapis.com/css?family=Dancing+Script);

* {
    margin: 0;
}

body {
    background-color: #e8f5ff;
    font-family: Arial;
    overflow: hidden;
}
    .main {
    margin-top: 10%;
    margin-left: 29%;
    font-size: 28px;
    padding: 10px 0px;
    width: 60%;
}

.main h2 {
    color: #333;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-size: 24px;
    margin-bottom: 10px;
}

.main .card {
    background-color: #fff;
    border-radius: 18px;
    box-shadow: 1px 1px 8px 0 grey;
    height: auto;
    margin-bottom: 20px;
    padding: 20px 0 20px 50px;
}

.main .card table {
    border: none;
    font-size: 16px;
    height: 270px;
    width: 80%;
}

.edit {
    position: absolute;
    color: #e7e7e8;
    right: 14%;
}

.social-media {
    text-align: center;
    width: 90%;
}

.social-media span {
    margin: 0 10px;
}

.fa-facebook:hover {
    color: #4267b3 !important;
}

.fa-twitter:hover {
    color: #1da1f2 !important;
}

.fa-instagram:hover {
    color: #ce2b94 !important;
}

.fa-invision:hover {
    color: #f83263 !important;
}

.fa-github:hover {
    color: #161414 !important;
}

.fa-whatsapp:hover {
    color: #25d366 !important;
}

.fa-snapchat:hover {
    color: #fffb01 !important;
}

/* End */
  </style>
</head>
<body>
  <div class="main">
    <h2>IDENTITY</h2>
    <div class="card">
        <div class="card-body">
            <i class="fa fa-pen fa-xs edit"></i>
            <table>
                <tbody>
                    <tr>
                        <td>Name</td>
                        <td>:</td>
                        <td>ImDezCode</td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td>imdezcode@gmail.com</td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td>:</td>
                        <td>Bali, Indonesia</td>
                    </tr>
                    <tr>
                        <td>Hobbies</td>
                        <td>:</td>
                        <td>Diving, Reading Book</td>
                    </tr>
                    <tr>
                        <td>Job</td>
                        <td>:</td>
                        <td>Web Developer</td>
                    </tr>
                    <tr>
                        <td>Skill</td>
                        <td>:</td>
                        <td>PHP, HTML, CSS, Java</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <h2>SOCIAL MEDIA</h2>
    <div class="card">
        <div class="card-body">
            <i class="fa fa-pen fa-xs edit"></i>
            <div class="social-media">
                <span class="fa-stack fa-sm">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-facebook fa-stack-1x fa-inverse"></i>
                </span>
                <span class="fa-stack fa-sm">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-twitter fa-stack-1x fa-inverse"></i>
                </span>
                <span class="fa-stack fa-sm">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-instagram fa-stack-1x fa-inverse"></i>
                </span>
                <span class="fa-stack fa-sm">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-invision fa-stack-1x fa-inverse"></i>
                </span>
                <span class="fa-stack fa-sm">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-github fa-stack-1x fa-inverse"></i>
                </span>
                <span class="fa-stack fa-sm">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-whatsapp fa-stack-1x fa-inverse"></i>
                </span>
                <span class="fa-stack fa-sm">
                    <i class="fas fa-circle fa-stack-2x"></i>
                    <i class="fab fa-snapchat fa-stack-1x fa-inverse"></i>
                </span>
            </div>
        </div>
    </div>
</div>
<!-- End 
</body>
</html> -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        *
{
    padding: 0px;
    text-align: center;
}
.container {
    padding: 16px;
   
}
h2{
    margin-top: 4px;
    font-family: -apple-ystem, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    text-align: center;
    

}
.avatar
{
    width:100px;
    height:100px;
    vertical-align: middle;

}
.Registration
{
    margin: auto;
    width: 550px;
    margin-top: 30px;
    margin-bottom: 30px;
    box-sizing: border-box;
    border: 1px solid rgba(0,0,0.1);
    box-shadow: 0 5px 10px rgba(0,0,0.2);
}
input[type=text],input[type=tel],input[type=email], input[type=password], input[type=date],select{
    width:400px;
    border: none;
    padding:12px 20px  ;
    text-align: left;
    margin:5px 0px;
    display: inline-block;
    border:1px solid blue;
    border-radius: 5px;
    
}
input[type=Submit]
{
    width: 300px;
    padding: 14px 20px; 
    background-color:#4CAF50;
    border: none;
    cursor: pointer;
    margin-top: 20px;
    color:#000;
    font-weight: bold;
    font-variant: small-caps;
    border-radius: 1em;
}
input[type=Submit]:hover{
    opacity: 0.8;
}

div  label{    
    font-weight: bolder;
    padding: 3px;
    margin: 0px ;
    text-align: left;

}
select:focus,input[type=tel]:focus,input[type=text]:focus,input[type=email]:focus, input[type=password]:focus, input[type=date]:focus{
    border: 2px solid blue;
}
input[type=radio]
{
    margin-left:10px ;
    display: inline-table;
}



    </style>
</head>
<body>
    <div class="Registration">
        <h2> Update Profile..</h2>
        <div class="container">
          <form action="<?php echo site_url('welcome/updateuserprofile') ?>" method="post">
            <img class="avatar" src="<?php echo base_url('images/sh.jpg'); ?>" alt="avatar image">
            <br>
            <br>
            <label style="text-align: left;">Full Name:</label><br>
            <input type="text" name="name" placeholder="Name.."  value="<?php echo $row->name?>" required>
            <br>
            <label>Email:</label> <br>
            <input type="text" name="email" placeholder="Email Address.."  value="<?php echo $row->email?>" required>
            <br>
            <label>Phone Number</label><br>
            <input type="tel" name="phnumber" value="<?php echo $row->phnumber?>" required><br>
            <br>
            <label>Address</label><br>
            <input type="text" name="Address" placeholder="Enter the address..." value="<?php echo $row->Address?>">
            <br>
            
            <input type="Submit" value="Update">
    
        </div>
        <p>Don't Update <a href="<?php echo base_url().'index.php/welcome/userwelcome' ?>" style="color:red; font-size: 20px;">back ??</a> </p> 
        </form>
    
      </div>
    
</body>
</html>
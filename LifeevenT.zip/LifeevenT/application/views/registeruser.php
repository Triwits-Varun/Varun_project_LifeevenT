<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css'>
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
}

* {
  box-sizing: border-box;
}

/* Style inputs */
input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=tel], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=password], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=email], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}
input[type=submit] {
  background-color: #04AA6D;
  color: white;
  padding: 12px 20px;
  border: none;
  cursor: pointer;
}

input[type=submit]:hover {
  background-color: #45a049;
}

/* Style the container/contact section */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 10px;
}

/* Create two columns that float next to eachother */
.column {
  float: left;
  width: 50%;
  margin-top: 6px;
  padding: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}



/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}
</style>
</head>
<body>
<div class="container">
  <div style="text-align:center">
    <h2>Contact Us</h2>
    <h2>Contact Us</h2>
    <h2>Register User</h1>
    <p>We respect your effort to Registering with us thank you!!!!</p>
    <p>Let's make the event Memorable</p>
  </div>
  <div class="row">
    <div class="column">
      <img src="<?php echo base_url('images/joinus.jpg'); ?>" height="80%" width="80%">


    </div>
    <div class="column">
      <form action="<?php echo base_url().'index.php/welcome/registeruser' ?>" method="post">
        <label >Name</label>
        <input type="text" id="name" name="name" placeholder="Your name.." onkeypress="return allowOnlyLetters(event,this);" required>
        <label >Email ID</label>
        <input type="email" id="email" name="email" placeholder="Your email.." required>
        <label >Phone Number</label>
        <input type="tel" id="phnumber" name="phnumber" onkeypress="return onlyNumberKey(event)" maxlength="10" placeholder="Your Phone Number .." required>
        <label for="password">Password</label>
        <input id="password" name="password" type="password" placeholder="Your Pasword.."  maxlength="8" required>
        <label for="confirm_password">Confirm Password</label>
        <input id="confirm_password" name="confirm_password" placeholder="Confirm Your Password ...." type="password" maxlength="8" required>
        <label for="confirm_password">check the box to confirm password</label>
        <input type="checkbox"required onclick="return Validate()" class="check" required><br>

        <input type="submit">
        <p>Already Registered Please <a href="<?php echo base_url().'index.php/welcome/userloginview' ?>" style="color:red; font-size: 20px;">Login ??</a> </p> 
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
      // this function will allow onlu characters in the input field
      function allowOnlyLetters(e, t)  {    
        if (window.event){    
          var charCode = window.event.keyCode;    
        } else if (e){    
          var charCode = e.which;    
        }else { return true; }  
        // Only ASCII character in that range allowed  
        if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123) || (charCode == 32))    
          return true;    
        else{    
          return false;
        }
      } 
      function onlyNumberKey(evt) {
              
              // Only ASCII character in that range allowed
              var ASCIICode = (evt.which) ? evt.which : evt.keyCode
              if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))
                  return false;
              return true;
          } 
          function Validate( ) {
        var password = document.getElementById("password").value;
        var confirm_password = document.getElementById("confirm_password").value;
        if (password != confirm_password) {
            alert("Passwords do not match.");
            return false;
        }
        return true;
      }   
</script>
</body>
</html>

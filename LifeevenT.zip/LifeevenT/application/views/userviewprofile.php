<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
    /* Import Font Dancing Script */
@import url(https://fonts.googleapis.com/css?family=Dancing+Script);

* {
    margin: 0;
}

body {
    background-color: #e8f5ff;
    font-family: Arial;
    overflow: hidden;
}
    .main {
    margin-top: 10%;
    margin-left: 29%;
    font-size: 28px;
    padding: 10px 0px;
    width: 60%;
}

.main h2 {
    color: #333;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    font-size: 24px;
    margin-bottom: 10px;
}

.main .card {
    background-color: #fff;
    border-radius: 18px;
    box-shadow: 1px 1px 8px 0 grey;
    height: auto;
    margin-bottom: 20px;
    padding: 20px 0 20px 50px;
}

.main .card table {
    border: none;
    font-size: 16px;
    height: 270px;
    width: 80%;
}

.edit {
    position: absolute;
    color: #e7e7e8;
    right: 14%;
}

.social-media {
    text-align: center;
    width: 90%;
}

.social-media span {
    margin: 0 10px;
}

.fa-facebook:hover {
    color: #4267b3 !important;
}

.fa-twitter:hover {
    color: #1da1f2 !important;
}

.fa-instagram:hover {
    color: #ce2b94 !important;
}

.fa-invision:hover {
    color: #f83263 !important;
}

.fa-github:hover {
    color: #161414 !important;
}

.fa-whatsapp:hover {
    color: #25d366 !important;
}

.fa-snapchat:hover {
    color: #fffb01 !important;
}

/* End */
  </style>
</head>
<body>
  <div class="main">
    <h2>IDENTITY</h2>
    <div class="card">
        <div class="card-body">
            <i class="fa fa-pen fa-xs edit"></i>
            <table>
                <tbody>
                    <tr>
                        <td>Name</td>
                        <td>:</td>
                        <td>ImDezCode</td>
                    </tr>
                    <tr>
                        <td>Email</td>
                        <td>:</td>
                        <td>imdezcode@gmail.com</td>
                    </tr>
                    <tr>
                        <td>Address</td>
                        <td>:</td>
                        <td>Bali, Indonesia</td>
                    </tr>
                    <tr>
                        <td>Hobbies</td>
                        <td>:</td>
                        <td>Diving, Reading Book</td>
                    </tr>
                    <tr>
                        <td>Job</td>
                        <td>:</td>
                        <td>Web Developer</td>
                    </tr>
                    <tr>
                        <td>Skill</td>
                        <td>:</td>
                        <td>PHP, HTML, CSS, Java</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    
</div>
<!-- End -->
</body>
</html>
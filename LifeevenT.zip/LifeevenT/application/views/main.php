<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <style>
       @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins',sans-serif;
}
::selection{
  color: #000;
  background: #fff;
}
nav{
  position: fixed;
  background: #1b1b1b;
  width: 100%;
  padding: 10px 0;
  z-index: 12;
}
nav .menu{
  max-width: 1250px;
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}
.menu .logo a{
  text-decoration: none;
  color: #fff;
  font-size: 35px;
  font-weight: 600;
}
.menu ul{
  display: inline-flex;
}
.menu ul li{
  list-style: none;
  margin-left: 7px;
}
.menu ul li:first-child{
  margin-left: 0px;
}
.menu ul li a{
  text-decoration: none;
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  padding: 8px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.menu ul li a:hover{
  background: #fff;
  color: black;
}
.img{
  background: url('img3.jpg')no-repeat;
  width: 100%;
  height: 100vh;
  background-size: cover;
  background-position: center;
  position: relative;
}
.img::before{
  content: '';
  position: absolute;
  height: 100%;
  width: 100%;
  background: rgba(0, 0, 0, 0.4);
}
.center{
  position: absolute;
  top: 52%;
  left: 50%;
  transform: translate(-50%, -50%);
  width: 100%;
  padding: 0 20px;
  text-align: center;
}
.center .title{
  color: #fff;
  font-size: 55px;
  font-weight: 600;
}
.center .sub_title{
  color: #fff;
  font-size: 52px;
  font-weight: 600;
}
.center .btns{
  margin-top: 20px;
}
.center .btns button{
  height: 55px;
  width: 170px;
  border-radius: 5px;
  border: none;
  margin: 0 10px;
  border: 2px solid white;
  font-size: 20px;
  font-weight: 500;
  padding: 0 10px;
  cursor: pointer;
  outline: none;
  transition: all 0.3s ease;
}
.center .btns button:first-child{
  color: #fff;
  background: none;
}
.btns button:first-child:hover{
  background: white;
  color: black;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}

.services {
  padding: 50px;
  text-align: center;
  background-color: #474e5d;
  color: white;
}

.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
.mySlides {
    display: none;
    background: rgba(0, 0, 0, 0.4);
}
/* Slideshow container */
.slideshow-container {
    width: 100%;
    height: 100%;
    max-height: 100vh;
    margin: auto;
      background: rgba(0, 0, 0, 0.4);
}
/* The dots/bullets/indicators */
.dot {

    height: 15px;
    width: 15px;
    margin: 0 2px;
    background-color: #bbb;
    border-radius: 50%;
    display: inline-block;
    transition: background-color 0.6s ease;

}

.active {
    background: rgba(0, 0, 0, 0.4);
}

/* Fading animation */
.fade {
    -webkit-animation-name: fade;
    -webkit-animation-duration: 1.5 s;
    animation-name: fade;
    animation-duration: 1.5 s;
}

@-webkit-keyframes fade {
    from {
        opacity: .4
    }

    to {
        opacity: 1
    }
}

@keyframes fade {
    from {
        opacity: .4
    }

    to {
        opacity: 1
    }
}

/* On smaller screens, decrease text size */
@media only screen and (max-width: 300px) {

    .prev,
    .next,
    .text {
        font-size: 11px
    }
}

/* Next & previous buttons */
.prev,
.next {
    cursor: pointer;
    position: absolute;
    top: 50%;
    width: auto;
    padding: 16px;
    margin-top: -22px;
    color: white;
    font-weight: bold;
    font-size: 18px;
    transition: 0.6s ease;
    border-radius: 0 3px 3px 0;
    user-select: none;
}

/* Position the "next button" to the right */
.next {
    right: 0;
    border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
    background-color: rgba(0, 0, 0, 0.8);
}

    </style>
   </head>
<body>
  
  <div class="img">
    
    <div class="slideshow-container">
        <?php
    $cnt=1;
    foreach($result as $row)
    {
    ?>
        <div class="mySlides fade">
            <img src="<?php echo base_url('uploads/background/' . $row->file); ?>" style="width: 100vw;height: 100vh ;background-color:rgba(0, 0, 0, 0.4) ;">

        </div>
        <?php
    $cnt++;
    } ?>
       
        <div style="text-align:center; margin:-5vh;">

            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>
            <span class="dot"></span>

        </div>
        <a class="prev" onclick="prevSlide()">&#10094;</a>
        <a class="next" onclick="showSlides()">&#10095;</a>
    </div>
    <!-- <img src="<?php echo base_url('images/background.jpg'); ?>" height="100%" width="100%"> --></div>
    

  <div class="center">
    <div class="title">Let's Make Your Next</div>
    <div class="sub_title">Celebration Special</div>

    <div class="btns">
      
      <a href="<?php echo base_url().'index.php/welcome/contactview' ?>"><button >Get a callBack</button></a>
    </div>
  </div>
  <div>

    <div class="services" id="services">
      <h2>_________________</h2>
      <h1>Services Provided</h1>
      <p>We organise all types of events cultural,western etc.....</p>
      <p>Some of the event organised</p>
    </div>
    
    <h2 style="text-align:center">Recently organised</h2>
    <div class="row">
      <div class="column">
        <div class="card">
          <img src="<?php echo base_url('images/indian.jpg'); ?>" alt="indian wedding" style="width:100%" height="460px">
          <div class="container">
            <h2>Indian Wedding</h2>
            <p class="title">Banglore</p>
            <p>It was the cultural event organised by lifeevent in banglore.</p>
            <a><button class="button"></button></a>
          </div>
        </div>
      </div>
    
      <div class="column">
        <div class="card">
          <img  src="<?php echo base_url('images/western.jpg'); ?>" alt="western wedding" style="width:100%" height="460px">
          <div class="container">
            <h2>Western Wedding</h2>
            <p class="title">Goa</p>
            <p>It was a western culture event organised by lifeevent at Goa</p>
            <p><button class="button"></button></p>
          </div>
        </div>
      </div>
      
      <div class="column">
        <div class="card">
          <img src="<?php echo base_url('images/birthday.jpg'); ?>" alt="Birthday party" style="width:100%" height="460px">
          <div class="container">
            <h2>Birthday Party</h2>
            <p class="title">Mumbai</p>
            <p>It was Birthday party of a kid organised by lifeevent at mumbai </p>
            <p><button class="button"></button></p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script type="text/javascript">
     var timeOut = 1000;
        var slideIndex = 0;
        var autoOn = true;

        autoSlides();

        function autoSlides() {
            timeOut = timeOut - 20;

            if (autoOn == true && timeOut < 0) {
                showSlides();
            }
            setTimeout(autoSlides, 20);
        }

        function prevSlide() {

            timeOut = 5000;

            var slides = document.getElementsByClassName("mySlides");
            var dots = document.getElementsByClassName("dot");

            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slideIndex--;

            if (slideIndex > slides.length) {
                slideIndex = 1
            }
            if (slideIndex == 0) {
                slideIndex = 3
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
        }

        function showSlides() {

            timeOut = 5000;

            var slides = document.getElementsByClassName("mySlides");
            var dots = document.getElementsByClassName("dot");

            for (i = 0; i < slides.length; i++) {
                slides[i].style.display = "none";
                dots[i].className = dots[i].className.replace(" active", "");
            }
            slideIndex++;

            if (slideIndex > slides.length) {
                slideIndex = 1
            }
            slides[slideIndex - 1].style.display = "block";
            dots[slideIndex - 1].className += " active";
        }
  </script>
</body>
</html>
 
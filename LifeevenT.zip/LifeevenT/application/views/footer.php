<style type="text/css">
    footer {
  text-align: center;
  padding: 3px;
  background-color: rgb(0, 0, 0);
  color: white;
}
</style>


<footer>
    
    <p>  <span>&#9993;</span> 
    <a href=""> lifeenent@gmail.com</a> <span>&#169; Lifeevent 2018-23</span></p>
</footer>
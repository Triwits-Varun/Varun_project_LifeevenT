
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
    <style>
  *,
*::before,
*::after {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  min-height: 100vh;
  font-family: "Franklin Gothic Medium", "Arial Narrow", Arial, sans-serif;
}

nav {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1rem;
  background-color: #333;
  color: white;
  position: relative;
}

/* responsive */
nav.active {
  flex-direction: column;
  align-items: flex-start;
}

nav h2.logo {
  font-weight: bold;
  font-size: xx-large;
}

nav .bars {
  position: absolute;
  right: 1rem;
  font-size: xx-large;
  display: none;
}

ul.nav-links {
  display: flex;
}

/* responsive */
nav.active ul.nav-links {
  display: flex;
  flex-direction: column;
  width: 100%;
  align-items: center;
}

li.nav-link {
  list-style: none;
  margin: 0.5rem 1rem;
  padding: 0.4rem;
  display: flex;
  align-items: center;
}

li.nav-link:hover {
  background-color: #ccc;
  color: #333;
}

li.nav-link.auth {
  border: 2px solid white;
  border-radius: 1rem;
}

li.nav-link a {
  text-decoration: none;
  color: inherit;
  font-family: "Gill Sans", "Gill Sans MT", Calibri, "Trebuchet MS", sans-serif;
  font-size: large;
  text-transform: uppercase;
}

@media screen and (max-width: 800px) {
  nav .bars {
    display: block;
  }

  nav .nav-links {
    display: none;
  }
}

/* It is ready */
/* Have a good time */

    </style>
</head>
<body>
    <nav>
  <h2 class="logo">LifeevenT</h2>
  <div class="bars">
    <i class="fa fa-bars"></i>
  </div>
  <ul class="nav-links">
    <li class="nav-link"><a href="<?php echo base_url().'index.php/welcome/main' ?>">Home</a></li>
    <li class="nav-link"><a href="<?php echo base_url().'index.php/welcome/about' ?>">About</a></li>
    <li class="nav-link"><a href="<?php echo base_url().'index.php/welcome/contactview' ?>">Contact</a></li>
    <li class="nav-link"><a href="#services">Services</a></li>
    <li class="nav-link"><a href="<?php echo base_url().'index.php/welcome/review' ?>">Review</a></li>
    <li class="nav-link auth"><a href="<?php echo base_url().'index.php/welcome/loginview' ?>">Admin</a></li>
    
  </ul>
</nav>
<script type="text/javascript">
    const bars = document.querySelector(".bars");
const nav = document.querySelector("nav");

bars.onclick = () => {
  nav.classList.toggle("active");
};
</script>
</body>
</html>
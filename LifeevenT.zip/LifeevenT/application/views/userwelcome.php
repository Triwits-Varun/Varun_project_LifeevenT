<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CountDown Timer</title>
 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  @import url("https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap");

* {
  box-sizing: border-box;
}

body {
  background-image: url("<?php echo base_url('images/welcome5.jpg'); ?>");
  background-size: cover;
  background-position: center center;
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 100%;
  min-height: 100%;
  font-family: "Roboto", sans-serif;
  margin: 0;


}

h1 {
  color: azure;
  font-weight: 600;
  font-size: 5rem;
 
}

.countdown-container {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: center;
}

.big-text {
  color: azure;
  font-weight: bold;
  font-size: 5rem;
  line-height: 1;
  margin: 1.5rem 2rem;
  flex-wrap: wrap;
  text-align: center;
}

.element {
  text-align: center;
}

.element span {
  color: azure;
  font-size: 1.3rem;
}

</style>

<body>

  
  <h1>-------Welcome------- <br>We Are planing Your event</h1>
  
  <div class="element countdown-container">
    <div class="element days-c">
      <p class="big-text" id="days">0</p>
      <span>Days</span>
    </div>
    <div class="element hours-c">
      <p class="big-text" id="hours">0</p>
      <span>Hours</span>
    </div>
    <div class="element minutes-c">
      <p class="big-text" id="minutes">0</p>
      <span>Minutes</span>
    </div>
    <div class="element seconds-c">
      <p class="big-text" id="seconds">0</p>
      <span>Seconds</span>
    </div>
  </div>
  <p>
    <a href="<?php echo base_url().'index.php/welcome/userlogout' ?>" class="btn btn-info btn-lg">
        <span class="glyphicon glyphicon-log-out"></span> Log out
    </a>
  </p> 
</body>
<script type="text/javascript">
  const dayselement = document.getElementById("days");
const hourselement = document.getElementById("hours");
const minuteselement = document.getElementById("minutes");
const secondselement = document.getElementById("seconds");

const newYears = "26 APR 2023";

function countdown() {
  const newYearsDate = new Date(newYears);
  const currentDate = new Date();

  const totalSeconds = (newYearsDate - currentDate) / 1000;

  const days = Math.floor(totalSeconds / 3600 / 24);
  const hours = Math.floor(totalSeconds / 3600) % 24;
  const minutes = Math.floor(totalSeconds / 60) % 60;
  const seconds = Math.floor(totalSeconds) % 60;

  dayselement.innerHTML = formatTime(days);
  hourselement.innerHTML = formatTime(hours);
  minuteselement.innerHTML = formatTime(minutes);
  secondselement.innerHTML = formatTime(seconds);
}

function formatTime(time) {
  return time < 10 ? `0${time}` : time;
}

// Initial Call
countdown();

setInterval(countdown, 1000);
</script>

</html>
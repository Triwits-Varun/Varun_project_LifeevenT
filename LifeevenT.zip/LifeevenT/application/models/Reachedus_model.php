 <?php 

class Reachedus_model extends CI_Model{
    public function getreachedus(){
    $ret=$this->db->select('*')
                
                  ->get('contact');
            return $ret->result();
    }
    public function getcustomerreview(){
    $ret=$this->db->select('*')
                
                  ->get('customerreview');
            return $ret->result();
    }
    // this function will save tha data of the user in database, it is pass bt reference
    public function addevent($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('event',$formArray);
        return true;
    }
    public function addreview($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('review',$formArray);
        return true;
    }
     public function uploadimg($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('galary',$formArray);
        return true;
    }
       public function gettask(){
    $ret=$this->db->select('*')
                  
                  ->not_like('status', 'Done')
                
                  ->get('event');
            return $ret->result();
    }
    public function completedevent(){
    $ret=$this->db->select('*')
                  
                  ->like('status', 'Done')
                
                  ->get('event');
            return $ret->result();
    }
     public function get($id){
        $ret=$this->db->select('*')->where('id',$id)
                
                  ->get('event');
            return $ret->row();
    }
    public function updateevent($id){
$data=array(
            
'name'=>$this->input->post('name'),
'email'=>$this->input->post('email'),
'phnumber'=>$this->input->post('phnumber'),
'location'=>$this->input->post('location'),
'date_time'=>$this->input->post('date_time'),
'event'=>$this->input->post('event'),
'status'=>$this->input->post('status'),
);
//print_r($data);exit;
$sql_query= $this->db->where('id', $id)
                ->update('event', $data);
           if($sql_query){
             echo '<script>alert("Event update Sucessesfull")</script>';
        
    }
    else{
       echo '<script>alert("Event update Failed")</script>';
    }
}

public function deleteevent($id)
    {
        $this->db->where("id", $id);
$this->db->delete("event");
return true;

    }
    public function authenticate($input=NULL)
    {
        $query = $this->db->query('SELECT * FROM admin');
        $rows = $query->result_array();
        foreach($rows as $check)
        {
            if($input['password']==$check['password'])
            {
                if($input['name']==$check['name'])
                {
                    //session_start();
                    $_SESSION['login'] = "T";
                    $_SESSION['name'] = $input['name'];
                    //is it unsafe to keep password?
                    $_SESSION['password'] = $input['password'];
                    return true;
                    //maybe break here is redundant,but dont want risk
                    break;
                }
            }
        }
        return false;
    }  
    public function search($search)
{
    $this->db->select('*');
    $this->db->from('event');
    $this->db->like('name',$search);
    $this->db->or_like('email',$search);
    $this->db->or_like('phnumber',$search);
    $this->db->or_like('location',$search);
    $this->db->or_like('date_time',$search);
    $this->db->or_like('event',$search);
    $this->db->or_like('status',$search);
    $query = $this->db->get();
    return $query->result();
}
public function contactsearch($search)
{
    $this->db->select('*');
    $this->db->from('contact');
    $this->db->like('name',$search);
    $this->db->or_like('email',$search);
    $this->db->or_like('country',$search);
    $this->db->or_like('subject',$search);
    $query = $this->db->get();
    return $query->result();
}
public function customerreviewsearch($search)
{
    $this->db->select('*');
    $this->db->from('customerreview');
    $this->db->like('name',$search);
    $this->db->or_like('email',$search);
    $this->db->or_like('phnumber',$search);
    $this->db->or_like('event',$search);
    $this->db->or_like('review',$search);
    $query = $this->db->get();
    return $query->result();
}


/*================================ Email Function Authentication Start============================*/public function authenticatemail($input=NULL)
    {
        $query = $this->db->query('SELECT * FROM admin');
        $rows = $query->result_array();
        foreach($rows as $check)
        {
            if($input['email']==$check['email'])
            {
                //session_start();
                $_SESSION['login'] = "T";
                $_SESSION['email'] = $input['email'];
                //is it unsafe to keep password?
                return true;
                //maybe break here is redundant,but dont want risk
                break;
            }
        }
        return false;
    } 

    /*================================ Email Function Authentication End=========================*/





    /*================================ Email confirmation Start=========================*/
     public function sendEmailpass($to_email)
    {
        $from_email = 'varuntriwits123@gmail.com'; //change this to yours
        $subject = 'Your meaasge Has Sucessfully reached Us';
        $message = '
                        <html>
                        <head>
                            <title>Conformation Mail</title>
                        </head>
                        <body>
                            <h1>Hello </h1>
                            <h3>Change of Password</h3>
                            <p>You can change the password by clicking the link </p>
                            <p>Check Link : http://localhost/LifeevenT/index.php/welcome/confirmpass </p>
                            <p>Any Issues Please Contact Us </p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';

        $this->load->library('email'); 
      /*  //configure email settings
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.googlemail.com'; //smtp host name
        $config['smtp_port'] = '465'; //smtp port number
        $config['smtp_user'] = $from_email;
        $config['smtp_pass'] = 'thsjvrdaiuftrahz'; //$from_email password
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = TRUE;
        //use double quotes*/
        $config = Array(
            'protocol'  => 'smtp',
            'smtp_host' => 'ssl://smtp.gmail.com',
            'smtp_port' => '465',
            'smtp_user' => 'varuntriwits123@gmail.com',
            'smtp_pass' => 'qtbpvjjilaaifqxf',
            'mailtype'  => 'html',
            'smtp_timeout' => '60',
            'charset'   => 'iso-8859-1',
            'wordwrap'  => TRUE,
            'newline'   => "\r\n"
        );
        $this->load->library('email',$config);
        $this->email->initialize($config);
       
        
        //send mail
        $this->email->from($from_email);
        $this->email->to($to_email);
        $this->email->subject($subject);
        $this->email->message($message);
        return $this->email->send();
    }
    public function updatepass($email){
    $data=array(
            
    'password'=>$this->input->post('password'),
    );
//print_r($data);exit;
    $sql_query= $this->db->where('email', $email)
                ->update('admin', $data);
    if($sql_query){
        echo '<script>alert("Password update Sucessesfull")</script>';
        
    }
    else{
       echo '<script>alert("Password update Failed")</script>';
    }
}

/*================================ Email confirmation End=========================*/
/*=============================for uploading the user info to database =========================*/
public function registeruser($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('registeredusers',$formArray);
        return true;
    }
/*=================To Send email to registered email afert registration =========================*/
public function sendEmailregister($to_email,$name)
    {
        $from_email = 'varuntriwits123@gmail.com'; //change this to yours
        $subject = 'Thank You For Registering with us';
        $message = '
                        <html>
                        <head>
                            <title>Conformation Mail</title>
                        </head>
                        <body>
                            <h1>Hello '.$name.'</h1>
                            <h3>Conformation of registering Your account</h3>
                            <p>You can login Using the below link</p>
                            <p>Check Link : http://localhost/LifeevenT/index.php/welcome/userloginview </p>
                            <p>Any Issues Please Contact Us </p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';

        $this->load->library('email'); //to load email library
        $config = Array(
            'protocol'  => 'smtp',//set the prototype
            'smtp_host' => 'ssl://smtp.gmail.com',
            'smtp_port' => '465',
            'smtp_user' => 'varuntriwits123@gmail.com',//from email
            'smtp_pass' => 'qtbpvjjilaaifqxf',//password
            'mailtype'  => 'html',
            'smtp_timeout' => '60',
            'charset'   => 'iso-8859-1',
            'wordwrap'  => TRUE,
            'newline'   => "\r\n"
        );
        $this->load->library('email',$config);
        $this->email->initialize($config);
       
        
        //send mail
        $this->email->from($from_email);
        $this->email->to($to_email);
        $this->email->subject($subject);
        $this->email->message($message);
        return $this->email->send();
    }


/*=================for authentication of the user =========================*/

    public function authenticateuser($input=NULL)
    {
        $query = $this->db->query('SELECT * FROM registeredusers');
        $rows = $query->result_array();
        foreach($rows as $check)
        {
            if($input['password']==$check['password'])
            {
                if($input['email']==$check['email'])
                {
                    //session_start();
                    $_SESSION['login'] = "T";
                    $_SESSION['email'] = $input['email'];
                    //is it unsafe to keep password?
                    $_SESSION['password'] = $input['password'];
                    return true;
                    //maybe break here is redundant,but dont want risk
                    break;
                }
            }
        }
        return false;
    }
    /*================= Email Function Authentication for unon repeaded users=========================*/public function authenticatuniqueemail($input=NULL)
    {
        $query = $this->db->query('SELECT * FROM registeredusers');
        $rows = $query->result_array();
        foreach($rows as $check)
        {
            if($input['email']==$check['email'])
            {
                //session_start();
                $_SESSION['login'] = "T";
                $_SESSION['email'] = $input['email'];
                //is it unsafe to keep password?
                return true;
                //maybe break here is redundant,but dont want risk
                break;
            }
        }
        return false;
    } 

    /*================================ Email Function Authentication End=========================*/

}
 <?php 

class reachedus_model extends CI_Model{
    public function getreachedus(){
    $ret=$this->db->select('*')
                
                  ->get('contact');
            return $ret->result();
    }
    // this function will save tha data of the user in database, it is pass bt reference
    public function addevent($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('event',$formArray);
        return true;
    }
    public function addreview($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('review',$formArray);
        return true;
    }
     public function uploadimg($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('galary',$formArray);
        return true;
    }
       public function gettask(){
    $ret=$this->db->select('*')
                  
                  ->not_like('status', 'Done')
                
                  ->get('event');
            return $ret->result();
    }
    public function completedevent(){
    $ret=$this->db->select('*')
                  
                  ->like('status', 'Done')
                
                  ->get('event');
            return $ret->result();
    }
     public function get($id){
        $ret=$this->db->select('*')->where('id',$id)
                
                  ->get('event');
            return $ret->row();
    }
    public function updateevent($id){
$data=array(
            
'name'=>$this->input->post('name'),
'email'=>$this->input->post('email'),
'phnumber'=>$this->input->post('phnumber'),
'location'=>$this->input->post('location'),
'date_time'=>$this->input->post('date_time'),
'event'=>$this->input->post('event'),
'status'=>$this->input->post('status'),
);
//print_r($data);exit;
$sql_query= $this->db->where('id', $id)
                ->update('event', $data);
           if($sql_query){
             echo '<script>alert("Event update Sucessesfull")</script>';
        
    }
    else{
       echo '<script>alert("Event update Failed")</script>';
    }
}

public function deleteevent($id)
    {
        $this->db->where("id", $id);
$this->db->delete("event");
return true;

    }
    public function authenticate($input=NULL)
    {
        $query = $this->db->query('SELECT * FROM admin');
        $rows = $query->result_array();
        foreach($rows as $check)
        {
            if($input['password']==$check['password'])
            {
                if($input['name']==$check['name'])
                {
                    //session_start();
                    $_SESSION['login'] = "T";
                    $_SESSION['name'] = $input['name'];
                    //is it unsafe to keep password?
                    $_SESSION['password'] = $input['password'];
                    return true;
                    //maybe break here is redundant,but dont want risk
                    break;
                }
            }
        }
        return false;
    }  
}
<?php 
class User_model extends CI_Model {


	// this function will save tha data of the user in database, it is pass bt reference
	public function create($formArray){
		//to set the array data
		$this->db->set($formArray);
		// function to insert the data
		$this->db->insert('contact',$formArray);
        return true;
	}
    public function addcustomerreview($formArray){
        //to set the array data
        $this->db->set($formArray);
        // function to insert the data
        $this->db->insert('customerreview',$formArray);
        return true;
    }
	public function getuser(){
        $ret=$this->db->select('*')
                ->get('review');
            return $ret->result();
    }
    public function getimg(){
        $ret=$this->db->select('*')
                ->get('galary');
            return $ret->result();
    }
    public function sendEmail($to_email,$name)
    {
        $from_email = 'varuntriwits123@gmail.com'; //change this to yours
        $subject = 'Your meaasge Has Sucessfully reached Us';
        $message = '
                        <html>
                        <head>
                            <title>Conformation Mail</title>
                        </head>
                        <body>
                            <h1>Hello '.$name.'</h1>
                            <h3>Thank you for Reaching us out</h3>
                            <p>We respect your time to reaching us Based on your requirement ,our team will reach you Soon  </p>
                            <p>Contact us :</p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';
        
        //configure email settings
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = 'ssl://smtp.gmail.com'; //smtp host name
        $config['smtp_port'] = '465'; //smtp port number
        $config['smtp_user'] = $from_email;
        $config['smtp_pass'] = 'thsjvrdaiuftrahz'; //$from_email password
        $config['mailtype'] = 'html';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = TRUE;
        $config['newline'] = "\r\n"; //use double quotes
        $this->load->library('email');
        $this->email->initialize($config);
        
        //send mail
        $this->email->from($from_email);
        $this->email->to($to_email);
        $this->email->subject($subject);
        $this->email->message($message);
        return $this->email->send();
    }
    
}
?>
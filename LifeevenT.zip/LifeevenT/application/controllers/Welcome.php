<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->load->view('header');
		$this->load->model('User_model');
		 $data['result']=$this->User_model->getimg();
        $this->load->view('main', $data);
		$this->load->view('footer');
	}
	public function main(){
		$this->load->view('header');
		$this->load->model('User_model');
		 $data['result']=$this->User_model->getimg();
        $this->load->view('main', $data);;
		$this->load->view('footer');
	}
	public function about(){
		$this->load->view('header');
		$this->load->view('about');
		$this->load->view('footer');
	}
	public function contactview(){
		$this->load->view('header');
		$this->load->view('contact');
		$this->load->view('footer');
	}
	
	public function contactload(){

 	         // to load the register.php 	
 
 			// here the data is stored to database
 			$this->load->model('User_model');
 			//storing the data into the array
 			$formArray =array();
 			$formArray['name']= $this->input->post('name');
 			$formArray['email']= $this->input->post('email');
 			$formArray['country']= $this->input->post('country');
 			$formArray['subject']= $this->input->post('subject');

            // calling the create function in user_model
 			$check=$this->User_model->create($formArray);
             if($check==true){
                /*if ($this->User_model->sendEmail($this->input->post('email'),$this->input->post('name')))
                {
                    // successfully sent mail
                    echo '<script>alert("Mail Is sent kindly check the Mail")</script>';
                    
                }
                else
                {
                    // error
                  echo '<script>alert("UNABLE TO SEND THE MAIL")</script>';
                }*/
                
                $email = $this->input->post('email');
                $name = $this->input->post('name');
                $subject = 'Thank You For Reaching US ';
                $message = '
                        <html>
                        <head>
                            <title>Acknowledgement</title>
                        </head>
                        <body>
                            <h1>Hello '.$name.'</h1>
                            <h3>We respect Your effort For Reaching Us out</h3>
                            <p>Our Team will contact you soon </p>
                            <p>Any Issues Please Contact Us </p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';
        //Replacing Data with Keys
      

        

         //Sending email from localhost or live server
                $localhosts = array(
                     '::1',
                    '127.0.0.1',
                    'localhost'
                 );
        
            $protocol = 'mail';
            if (in_array($_SERVER['REMOTE_ADDR'], $localhosts)) {
                $protocol = 'smtp';
            }

            $config = array(
                    'protocol' => $protocol,
                    'smtp_host' => 'ssl://smtp.googlemail.com',
                    'smtp_port' => 465,
                    'smtp_user' => 'varuntriwits123@gmail.com',
                    'smtp_pass' => 'rmzgnbojemaywgvl',
                    'mailtype' => 'html',
                    'starttls'  => true,
                    'newline'   => "\r\n",
            );

        $this->load->library('email');
        $this->email->initialize($config);
        $this->email->from("varuntriwits123@gmail.com");
        $this->email->to("$email");
        $this->email->subject("Thank for Reaching Us Out");
        $this->email->message($message);
        $flag = $this->email->send();

        if($flag){
            echo '<script>alert("Mail Is sent kindly check the Mail")</script>';
           
        }else{
            echo '<script>alert("UNABLE TO SEND THE MAIL")</script>';
          
           
        }
        }
        else{
                echo "error !";
        }
            $this->load->view('header');
        	$this->load->model('User_model');
		 $data['result']=$this->User_model->getimg();
        $this->load->view('main', $data);;
        	$this->load->view('footer');
 		
 	}
    public function addcustomerreview(){

             // to load the register.php    
 
            // here the data is stored to database
            $this->load->model('User_model');
            //storing the data into the array
            $formArray =array();
            $formArray['name']= $this->input->post('name');
            $formArray['email']= $this->input->post('email');
            $formArray['phnumber']= $this->input->post('phnumber');
            $formArray['event']= $this->input->post('event');
            $formArray['review']= $this->input->post('review');

            // calling the create function in user_model
            $check=$this->User_model->addcustomerreview($formArray);
             if($check==true){
                echo '<script>alert("Review sent sucessesfully")</script>';
            }
             else{
                echo "error !";
                }
            $this->load->view('header');
            $this->load->model('User_model');
         $data['result']=$this->User_model->getimg();
        $this->load->view('main', $data);;
            $this->load->view('footer');
        
    }
 	public function review()
    {
    	 $this->load->view('header');
        $this->load->model('User_model');
        $data['result']=$this->User_model->getuser();
        $this->load->view('review', $data);
        $this->load->view('footer');
    }

    public function loginview()
	{
    		$this->load->view('adminlogin');
		
	}
    public function logout()
    {
        $this->session->unset_userdata('name');
        $this->session->sess_destroy();
        $this->load->view('header');
        $this->load->model('User_model');
         $data['result']=$this->User_model->getimg();
        $this->load->view('main', $data);
        $this->load->view('footer');
    }
     public function login()
    {
        $this->load->model('Reachedus_model');
        $name = $this->input->post('name');
        $password = $this->input->post('password');
        $input = array( 'name'=>$name, 'password'=>$password);

        $data['loggedIn'] = "no";
        $chk = $this->Reachedus_model->authenticate($input);
        if($chk){
            $_SESSION['name']= $this->input->post('name');
             $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getreachedus();
        $this->load->view('reached_us', $data);  

        }
        else{ 
            echo '<script>alert("Enter the valid email id and password")</script>';
            echo "<p style='color:red; text-align: center; '>Enter the valid email id and password</p>";
            $this->load->view('adminlogin');
            }
    }   
	public function addview(){
         if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{

		$this->load->view('headeradmin');
		$this->load->view('addevent');
        }
	}
	public function addevent(){
        if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
 			// here the data is stored to database
 			$this->load->model('Reachedus_model');
 			//storing the data into the array
 			$formArray =array();
 			$formArray['name']= $this->input->post('name');
 			$formArray['email']= $this->input->post('email');
 			$formArray['phnumber']= $this->input->post('phnumber');
 			$formArray['location']= $this->input->post('location');
 			$formArray['date_time']= $this->input->post('date_time');
 			$formArray['event']= $this->input->post('event');
 			$formArray['note']= $this->input->post('note');

            // calling the create function in user_model
 			$check=$this->Reachedus_model->addevent($formArray);
             if($check==true){
                echo '<script>alert("Event Added sucessesfully")</script>';
            }
             else{
                echo "error !";
                }
            $this->load->view('headeradmin');
		$this->load->model('Reachedus_model');
		 $data['result']=$this->Reachedus_model->getreachedus();
        $this->load->view('reached_us', $data);
        }     
 	}
 	public function reviewview(){
         if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
		$this->load->view('headeradmin');
		$this->load->view('addreview');
        }
	}
	public function dashboard(){
        if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
		$this->load->view('headeradmin');
		$this->load->model('Reachedus_model');
		 $data['result']=$this->Reachedus_model->getreachedus();
        $this->load->view('reached_us', $data);   
        }
	}
    public function Registeredwithus(){
         if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getrrgisteredwithus();
        $this->load->view('regwithus', $data);   
        }
    }
    public function viewcustomerreview(){
         if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getcustomerreview();
        $this->load->view('customerreview', $data);   
        }
    }
	public function addreview(){
        if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{ 
    // here the user_model is loaded
        $this->load->model('Reachedus_model');
        if(!empty($_FILES['picture']['name'])){
            //set the path for the image storage
                $config['upload_path'] = 'uploads/img/';
                // type of files allowed 
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    // file uploading is done by this
                    $uploadData = $this->upload->data();
                    // the filename name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
            
        //storing the data into the array
 		$formArray =array();
 		$formArray['name']= $this->input->post('name');
 		$formArray['event']= $this->input->post('event');
 		$formArray['note']= $this->input->post('note');
        $formArray['file']= $picture;

        // calling the create function in user_model
 		$check=$this->Reachedus_model->addreview($formArray);
        if($check==true){
            echo '<script>alert("review Added sucessesfully")</script>';
        }else{
            echo "error !";
        }
        // once the adding of data is completed the main in views/ is loaded
        $this->load->view('headeradmin');
		$this->load->view('addreview');
    }
    }
    public function addimage(){
        if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
		$this->load->view('headeradmin');
		$this->load->view('addimage');
        }
	}
	public function uploadimage(){
        if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
    // here the user_model is loaded
        $this->load->model('Reachedus_model');
        if(!empty($_FILES['picture']['name'])){
            //set the path for the image storage
                $config['upload_path'] = 'uploads/background/';
                // type of files allowed 
                $config['allowed_types'] = 'jpg|jpeg|png|gif|img|docx';
                $config['file_name'] = $_FILES['picture']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('picture')){
                    // file uploading is done by this
                    $uploadData = $this->upload->data();
                    // the filename name is stored in a variable
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = $this->input->post('picture');
                }
        }else{
            $picture = $this->input->post('picture');
        }
            
        //storing the data into the array
 		$formArray =array();
        $formArray['file']= $picture;

        // calling the create function in user_model
 		$check=$this->Reachedus_model->uploadimg($formArray);
        if($check==true){
            echo '<script>alert("Image uploaded sucessesfully")</script>';
        }else{
            echo "error !";
        }
        // once the adding of data is completed the main in views/ is loaded
        $this->load->view('headeradmin');
		$this->load->view('addimage');
    }
    }
    public function viewtask(){
         if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->gettask();
        $this->load->view('viewtask', $data);
        }
    }
     public function completedevent(){
         if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->completedevent();
        $this->load->view('completedevents', $data);
        }
    }
     public function updateeventview($id)
    {
         if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
        $data['row']=$this->Reachedus_model->get($id);
        $this->load->view('updateevent',$data);
       } 
    } 
    public function updateevent($id){
        if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
        $this->load->model('Reachedus_model');
        $this->Reachedus_model->updateevent($id);
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getreachedus();
        $this->load->view('reached_us', $data);
        }   
    }
    public function deleteevent($id)
{
    if(!$this->session->userdata('name')){
        $this->load->view('error');
    }else{
    $this->load->model('Reachedus_model');
    $response=$this->Reachedus_model->deleteevent($id);
    if($response==true){
        echo '<script>alert("Event deleted sucessesfully")</script>';
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getreachedus();
        $this->load->view('reached_us', $data); 
    }
    else{
        echo "error !";
    }
}
}
public function deleteuser($id)
{
     if(!$this->session->userdata('name')){
        $this->load->view('error');
    }else{
    $this->load->model('Reachedus_model');
    $response=$this->Reachedus_model->deleteuser($id);
    if($response==true){
        echo '<script>alert("user deleted sucessesfully")</script>';
        $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getrrgisteredwithus();
        $this->load->view('regwithus', $data); 
    }
    else{
        echo "error !";
    }
    }
}
public function emailcustomer($id)
    {
        if(!$this->session->userdata('name')){
            $this->load->view('error');
        }else{
        $this->load->model('Reachedus_model');
        $data['row']=$this->Reachedus_model->getmaildetails($id);
        $this->load->view('emailcustomer',$data);
        }
    } 
public function eventsearch(){
    if(!$this->session->userdata('name')){
        $this->load->view('error');
    }else{
     $this->load->model('Reachedus_model');
    $search = $this->input->post('search');
    $this->load->view('headeradmin');
    $data['result'] =  $this->Reachedus_model->search($search);
    $this->load->view('searchresult',$data);
    }
}
public function contactsearch(){
    if(!$this->session->userdata('name')){
        $this->load->view('error');
    }else{
     $this->load->model('Reachedus_model');
    $search = $this->input->post('search');
    $this->load->view('headeradmin');
    $data['result'] =  $this->Reachedus_model->contactsearch($search);
    $this->load->view('contactsearch',$data);
    }
}
public function customerreviewsearch(){
    if(!$this->session->userdata('name')){
        $this->load->view('error');
    }else{
     $this->load->model('Reachedus_model');
    $search = $this->input->post('search');
    $this->load->view('headeradmin');
    $data['result'] =  $this->Reachedus_model->customerreviewsearch($search);
    $this->load->view('searchreview',$data);
    }
}
public function registeredusersearch(){
    if(!$this->session->userdata('name')){
        $this->load->view('error');
    }else{
     $this->load->model('Reachedus_model');
    $search = $this->input->post('search');
    $this->load->view('headeradmin');
    $data['result'] =  $this->Reachedus_model->registeredusersearch($search);
    $this->load->view('searchuser',$data);
    }
}
public function forgotpass(){
        $this->load->view('forgotpass');
        $this->load->view('footer');
    }
    public function confirmpass(){

        $this->load->view('conformpass');
    }
    public function forgotpassmail(){
        $this->load->model('Reachedus_model');
        $email = $this->input->post('email');
        $input = array( 'email'=>$email);

        $data['loggedIn'] = "no";
        $chk = $this->Reachedus_model->authenticatemail($input);
        if($chk){
            /*if ($this->Reachedus_model->sendEmailpass($this->input->post('email')))
                {
                    // successfully sent mail
                    echo '<script>alert("Mail Is sent kindly check the Mail")</script>';
                    $this->load->view('adminlogin'); 
                    
                }
                else
                {
                    // error
                  echo '<script>alert("Mail found in database but Unable reach at the Moment")</script>';
                  $this->load->view('adminlogin');
                }*/ 
                $email = $this->input->post('email');
               $subject = 'Your meaasge Has Sucessfully reached Us';
                $message = '
                        <html>
                        <head>
                            <title>Conformation Mail</title>
                        </head>
                        <body>
                            <h1>Hello </h1>
                            <h3>Change of Password</h3>
                            <p>You can change the password by clicking the link </p>
                            <p>Check Link : https://lifeevent.tdc3030.com/index.php/welcome/confirmpass </p>
                            <p>Any Issues Please Contact Us </p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';
        //Replacing Data with Keys
      

        

         //Sending email from localhost or live server
                $localhosts = array(
                     '::1',
                    '127.0.0.1',
                    'localhost'
                 );
        
            $protocol = 'mail';
            if (in_array($_SERVER['REMOTE_ADDR'], $localhosts)) {
                $protocol = 'smtp';
            }

            $config = array(
                    'protocol' => $protocol,
                    'smtp_host' => 'ssl://smtp.googlemail.com',
                    'smtp_port' => 465,
                    'smtp_user' => 'varuntriwits123@gmail.com',
                    'smtp_pass' => 'rmzgnbojemaywgvl',
                    'mailtype' => 'html',
                    'starttls'  => true,
                    'newline'   => "\r\n",
            );

        $this->load->library('email');
        $this->email->initialize($config);
        $this->email->from("varuntriwits123@gmail.com");
        $this->email->to("$email");
        $this->email->subject("Change Of Password");
        $this->email->message($message);
        $flag = $this->email->send();

        if($flag){
            echo '<script>alert("Mail Is sent kindly check the Mail")</script>';
                    $this->load->view('adminlogin'); 
        }else{
            echo '<script>alert("Mail found in database but Unable reach at the Moment")</script>';
                  $this->load->view('adminlogin');
           
        }
        }
        else{ 
            echo '<script>alert("email not Registered Please try with Registered email ")</script>';
            $this->load->view('forgotpass');
        }
    }
    public function updatepass(){
        $this->load->model('Reachedus_model');
         $email = $this->input->post('email');
        $this->Reachedus_model->updatepass($email);
        $this->load->view('adminlogin');
    }
    /*to load the register user page*/
    public function registerview()
    {
        $this->load->view('header');
        $this->load->view('registeruser');
        $this->load->view('footer');
    }
    /*to store the registered user in the database and shoot a mail to the registered email*/
    public function registeruser(){

             // to load the register.php    
 
            // here the data is stored to database
            $this->load->model('Reachedus_model');
            //storing the data into the array
            $formArray =array();
            $formArray['name']= $this->input->post('name');
            $formArray['email']= $this->input->post('email');
            $formArray['phnumber']= $this->input->post('phnumber');
            $formArray['password']= $this->input->post('password');
            $formArray['Address']= $this->input->post('Address');
             $unique=$this->Reachedus_model->authenticatuniqueemail($formArray);
             if($unique==true){
                echo '<script>alert("Email is already registered")</script>';
            }else{

            // calling the create function in user_model
            $check=$this->Reachedus_model->registeruser($formArray);
             if($check==true){
                /*if ($this->Reachedus_model->sendEmailregister($this->input->post('email'),$this->input->post('name')))
                {
                    // successfully sent mail
                    echo '<script>alert("Mail Is sent kindly check the Mail")</script>';
                    
                }
                else
                {
                    // error
                  echo '<script>alert("Message not  sent")</script>';
                }*/

        $email = $this->input->post('email');
        $name = $this->input->post('name');
         $subject = 'Thank You For Registering with us';
        $message = '
                        <html>
                        <head>
                            <title>Conformation Mail</title>
                        </head>
                        <body>
                            <h1>Hello '.$name.'</h1>
                            <h3>Conformation of registering Your account</h3>
                            <p>You can login Using the below link</p>
                            <p>Check Link : https://lifeevent.tdc3030.com/index.php/welcome/userloginview </p>
                            <p>Any Issues Please Contact Us </p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';
        
        //Replacing Data with Keys
        
       

         //Sending email from localhost or live server
        $localhosts = array(
            '::1',
            '127.0.0.1',
            'localhost'
        );
        
        $protocol = 'mail';
        if (in_array($_SERVER['REMOTE_ADDR'], $localhosts)) {
            $protocol = 'smtp';
        }

        $config = array(
            'protocol' => $protocol,
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'varuntriwits123@gmail.com',
            'smtp_pass' => 'rmzgnbojemaywgvl',
            'mailtype' => 'html',
            'starttls'  => true,
            'newline'   => "\r\n",
        );

        $this->load->library('email');
        $this->email->initialize($config);
        $this->email->from("varuntriwits123@gmail.com");
        $this->email->to("$email");
        $this->email->subject("Thank You For Registering with us");
        $this->email->message($message);
        $flag = $this->email->send();

        if($flag){
           
            echo '<script>alert("email sent for Sucessfull Registration")</script>';
            
        }else{
            
            echo '<script>alert("Registration Was Sucessfull Unable To Send The Mail At The Moment")</script>';
            
        }

            }
             else{
                echo "error !";
                }
               } 
            $this->load->view('header');
            $this->load->model('User_model');
         $data['result']=$this->User_model->getimg();
        $this->load->view('main', $data);;
            $this->load->view('footer');
        
    }
    public function userloginview()
    {
        $this->load->view('userlogin');
        $this->load->view('footer');

    }
    public function userwelcome()
    {
        if(!$this->session->userdata('email')){
            $this->load->view('usererror');
        }else{ 
        $this->load->view('userdashboard');
        $data['row']=$this->Reachedus_model->userinfo($this->session->userdata('email'));
             $this->load->view('userprofilelogo',$data);
        $this->load->view('userwelcome');
        }
    }
    public function userlogin()
    {
        $this->load->model('Reachedus_model');
        $email = $this->input->post('email');
        $password = $this->input->post('password');
        $input = array( 'email'=>$email, 'password'=>$password);

        $data['loggedIn'] = "no";
        $chk = $this->Reachedus_model->authenticateuser($input);
        if($chk){
            $_SESSION['email']= $this->input->post('email');
            echo '<script>alert("Login sucessfull")</script>';
             $this->load->view('userdashboard');
             $data['row']=$this->Reachedus_model->userinfo($this->input->post('email'));
             $this->load->view('userprofilelogo',$data);
            $this->load->view('userwelcome'); 
        }
        else{ 
            echo '<script>alert("Enter the valid email id and password")</script>';
            echo "<p style='color:red; text-align: center; '>Enter the valid email id and password</p>";
            $this->load->view('userlogin');
            }
    }
    public function userlogout()
    {
        $this->session->unset_userdata('email');
        $this->session->sess_destroy();
        $this->load->view('header');
        $this->load->model('User_model');
         $data['result']=$this->User_model->getimg();
        $this->load->view('main', $data);
        $this->load->view('footer');
    } 
     public function customercontact(){
        $email = $this->input->post('email');
        $name = $this->input->post('name');
        $subject = $this->input->post('subject');
        $message = $this->input->post('message');
        $finalmessage = '
                        <html>
                        <head>
                            <title>Conformation Mail</title>
                        </head>
                        <body>
                            <h1>Hello '.$name.'</h1>
                            <h3>This Mail is from Team Lifeevent</h3>
                            <p> '.$message.'</p>
                            
                            <p>Any Issues Please Contact Us </p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';
        
        //Replacing Data with Keys
        
       

         //Sending email from localhost or live server
        $localhosts = array(
            '::1',
            '127.0.0.1',
            'localhost'
        );
        
        $protocol = 'mail';
        if (in_array($_SERVER['REMOTE_ADDR'], $localhosts)) {
            $protocol = 'smtp';
        }

        $config = array(
            'protocol' => $protocol,
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_user' => 'varuntriwits123@gmail.com',
            'smtp_pass' => 'rmzgnbojemaywgvl',
            'mailtype' => 'html',
            'starttls'  => true,
            'newline'   => "\r\n",
        );

        $this->load->library('email');
        $this->email->initialize($config);
        $this->email->from("varuntriwits123@gmail.com");
        $this->email->to("$email");
        $this->email->subject($subject);
        $this->email->message($finalmessage);
        $flag = $this->email->send();

        if($flag){
           
            echo '<script>alert("email sent to the customer")</script>';
             $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getrrgisteredwithus();
        $this->load->view('regwithus', $data);

            
        }else{
            
            echo '<script>alert("unable to send the email to the customer")</script>';
             $this->load->view('headeradmin');
        $this->load->model('Reachedus_model');
         $data['result']=$this->Reachedus_model->getrrgisteredwithus();
        $this->load->view('regwithus', $data);
            }
    } 
    public function userforgotpass(){
        $this->load->view('userforgotpass');
        $this->load->view('footer');
    }
    public function  userconfirmpass(){

        $this->load->view('userconfirmpass');
    }
     public function  userresendotp(){

        $this->load->view('userresendotp');
    }
    
    public function userforgotpassmail(){
        $this->load->model('Reachedus_model');
        $email = $this->input->post('email');
        $input = array( 'email'=>$email);

        $data['loggedIn'] = "no";
        $chk =$this->Reachedus_model->opttry($this->input->post('email'));
         /*$this->Reachedus_model->authenticatemailuserforgotpass($input);*/
         $optrepet=$this->Reachedus_model->otptodatabase($this->input->post('email'),$chk);
        if($optrepet){ 
        if($chk!=false){
            
                $email = $this->input->post('email');
               $subject = 'Your meaasge Has Sucessfully reached Us';
                $message = '
                        <html>
                        <head>
                            <title>Conformation Mail</title>
                        </head>
                        <body>
                            <h1>Hello </h1>
                            <h3>Change of Password</h3>
                            <p>You can change the password by clicking the link </p>
                            <p>The Otp Is '.$chk.'</p>
                            <p>Check Link : https://lifeevent.tdc3030.com/index.php/welcome/userconfirmpass </p>
                            <p>Any Issues Please Contact Us </p>
                            <p>Email: lifeevent@gmail.com</p>
                            <p>Thank Your.</p>
                            <h4>Team LifeevenT</h4>
                        </body>
                        </html>';
        //Replacing Data with Keys
      

        

         //Sending email from localhost or live server
                $localhosts = array(
                     '::1',
                    '127.0.0.1',
                    'localhost'
                 );
        
            $protocol = 'mail';
            if (in_array($_SERVER['REMOTE_ADDR'], $localhosts)) {
                $protocol = 'smtp';
            }

            $config = array(
                    'protocol' => $protocol,
                    'smtp_host' => 'ssl://smtp.googlemail.com',
                    'smtp_port' => 465,
                    'smtp_user' => 'varuntriwits123@gmail.com',
                    'smtp_pass' => 'rmzgnbojemaywgvl',
                    'mailtype' => 'html',
                    'starttls'  => true,
                    'newline'   => "\r\n",
            );

        $this->load->library('email');
        $this->email->initialize($config);
        $this->email->from("varuntriwits123@gmail.com");
        $this->email->to("$email");
        $this->email->subject("Change Of Password");
        $this->email->message($message);
        $flag = $this->email->send();

        if($flag){
            echo '<script>alert("Mail Is sent kindly check the Mail")</script>';
                     $this->load->view('useractionafterotp');
        }else{
            echo '<script>alert("Mail found in database but Unable reach at the Moment")</script>';
                  $this->load->view('userlogin');
        }
        
        }
        else{ 
            echo '<script>alert("email not Registered Please try with Registered email ")</script>';
            $this->load->view('userforgotpass');
        }
        }else{
            echo '<script>alert("click on resend otp ")</script>';
            $this->load->view('userforgotpass');
        }
    }
    public function updateuserpass(){
        $this->load->model('Reachedus_model');
        $email = $this->input->post('email');
        $OTP = $this->input->post('OTP');
        $input = array( 'email'=>$email, 'OTP'=>$OTP);
        $otpvalidate= $this->Reachedus_model->otpvalidation($input);
        if ($otpvalidate) {
            $updateuserpass=$this->Reachedus_model->updateuserpass($this->input->post('email'));
            if ($updateuserpass) {   
            $this->Reachedus_model->deleteOTP($this->input->post('email'));
            $this->load->view('userlogin');
            }
        }else{
            $this->load->view('userconfirmpass');
        }
    }
    /*-------------------Code for the bubble action--------------------*/
    public function userresetpassview()
    {
        if(!$this->session->userdata('email')){
            $this->load->view('usererror');
        }else{ 
        $this->load->view('userdashboard');
        $data['row']=$this->Reachedus_model->userinfo($this->session->userdata('email'));
             $this->load->view('userprofilelogo',$data);
        $this->load->view('userresetpass');
        }
    }
    public function updateuserresetpass(){
         if(!$this->session->userdata('email')){
            $this->load->view('usererror');
        }else{ 
        $this->load->model('Reachedus_model');
         $email = $this->session->userdata('email');
        $this->Reachedus_model->updateuserresetpass($email);
        $this->load->view('userdashboard');
        $data['row']=$this->Reachedus_model->userinfo($this->session->userdata('email'));
             $this->load->view('userprofilelogo',$data);
            $this->load->view('userwelcome');
    }
    }
    /*============================Update Profile==================*/
    public function updateuserprofileview()
    {
         if(!$this->session->userdata('email')){
            $this->load->view('error');
        }else{
        $this->load->model('Reachedus_model');
        $data['row']=$this->Reachedus_model->getuserinfo($this->session->userdata('email'));
        $this->load->view('updateuserprofile',$data);
       } 
    } 
   public function updateuserprofile(){
        if(!$this->session->userdata('email')){
            $this->load->view('error');
        }else{
        $this->load->model('Reachedus_model');
        $this->Reachedus_model->updateuserprofile($this->session->userdata('email'));
        $this->load->view('userdashboard');
        $data['row']=$this->Reachedus_model->userinfo($this->session->userdata('email'));
             $this->load->view('userprofilelogo',$data);
            $this->load->view('userwelcome');
        }   
    }

}

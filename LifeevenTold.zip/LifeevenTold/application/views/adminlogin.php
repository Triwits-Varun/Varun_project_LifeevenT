<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title>LifeevenT</title>
    <style>
        html,
body {
    background-image: url("<?php echo base_url('images/backlog2.jpg'); ?>");
    background-repeat: no-repeat;
    background-size: cover;   
    height: 100vh;
  
}

body {
  padding-top: 5rem;
  background-color: #f5f5f5;
}

.form-signin {
  max-width: 25rem;
  margin: auto;
}
.container2 {
    width: 500px;
    height:450px;
    margin: 30px;
    
    display: flex;
    background: rgb(214, 214, 214);
    border-radius: 10px;
    box-shadow: 5px 5px 7px gray, -5px -5px 7px gray;
  }


    </style>
  </head>
  <body class="text-center">
    <div class="container2">
    <main class="form-signin">
      <form  action="<?php echo base_url().'index.php/welcome/login' ?>" method="post">
        <h1 class="h3 mb-3 fw-normal"><b>LifeevenT</b> - Admin Login</h1>

        <div class="form-floating">
          <input type="text" class="form-control" id="name" name="name" placeholder="Enter a registered email">
          <label for="floatingInput">Used ID</label>
        </div>
        <div class="form-floating">
          <input type="password" class="form-control" id="password" name="password" placeholder="Password">
          <label for="floatingPassword">Password</label>
        </div>

        <button class="w-100 btn btn-lg btn-primary mt-3" type="submit">Login</button>
        
      </form>
    </main>
</div>

    <script src="login.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.16/dist/sweetalert2.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
  </body>
</html>
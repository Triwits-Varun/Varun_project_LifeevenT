<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
    <style>
       @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');
*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins',sans-serif;
}
::selection{
  color: #000;
  background: #fff;
}
nav{
  position: fixed;
  background: #1b1b1b;
  width: 100%;
  padding: 10px 0;
  z-index: 12;
}
nav .menu{
  max-width: 1250px;
  margin: auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 20px;
}
.menu .logo a{
  text-decoration: none;
  color: #fff;
  font-size: 35px;
  font-weight: 600;
}
.menu ul{
  display: inline-flex;
}
.menu ul li{
  list-style: none;
  margin-left: 7px;
}
.menu ul li:first-child{
  margin-left: 0px;
}
.menu ul li a{
  text-decoration: none;
  color: #fff;
  font-size: 18px;
  font-weight: 500;
  padding: 8px 15px;
  border-radius: 5px;
  transition: all 0.3s ease;
}
.menu ul li a:hover{
  background: #fff;
  color: black;
}

@media screen and (max-width: 650px) {
  .menu li {
    width: 100%;
    display: block;
  }
}
@media screen and (max-width: 500px) {
  .header a {
    float: none;
    display: block;
    text-align: left;
  }
  
  .menu ul{
    display: none;
  }
}

    </style>
   </head>
<body>
  <nav>
    <div class="menu">
      <div class="logo">
        <a href="#">LifeevenT</a>
      </div>
      <ul>
        <li><a href="<?php echo base_url().'index.php/welcome/main' ?>">Home</a></li>
        <li><a href="<?php echo base_url().'index.php/welcome/about' ?>">About</a></li>
        <li><a href="<?php echo base_url().'index.php/welcome/contactview' ?>">Contact</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="<?php echo base_url().'index.php/welcome/review' ?>">Review</a></li>
        <li><a href="<?php echo base_url().'index.php/welcome/loginview' ?>">Admin</a></li>
      </ul>
    </div>
  </nav>
</body>